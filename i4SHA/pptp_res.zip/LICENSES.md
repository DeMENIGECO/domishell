# MODULI USATI IN `pptp_res.zip` per: BUNDLES

## XAICA

**Percorso:** `pptp_res.zip/NotTestAmbient-Files/bundles/evrollement-file-bundle.XAICA.nvllmnt` \
**Spiegazione:** si usa per evitare conflitti. \
**Licenza:** No licenza \
**Testo licenza:** No testo licenza disponibile

## voc

**Percorso:** `pptp_res.zip/NotTestAmbient-Files/bundles/evrollement-file-bundle.voc.nvllmnt` \
**Spiegazione:** Per gestrie corretamente file C++ indesiderati \
**Licenza:** Apache 2.0 \
**Testo licenza:** https://apache.org/licenses/LICENSE-2.0.txt
## delbarket

**Percorso:** `pptp_res.zip/NotTestAmbient-Files/bundles/evrollement-file-bundle.delbarket.nvllmnt` \
**Spiegazione:** Per evitare conflitti per tutti i file indesiderati. \
**Licenza:** Apache 2.0 \
**Testo licenza:** https://apache.org/licenses/LICENSE-2.0.txt

---

# MODULI USATI IN `pptp_res.zip` per: FAT

## vo

**Percorso:** `pptp_res.zip/NotTestAmbient-Files/fat/vo` \
**Spiegazione:** per gestire meglio SHA32 \
**Licenza:** MIT \
**Testo licenza:** https://opensource.org/license/mit

---


# DISCALIMER

Il **copyright** è attribuito ai legittimi **autori originali**.